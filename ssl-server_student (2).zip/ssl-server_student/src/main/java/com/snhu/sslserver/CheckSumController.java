package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class CheckSumController {

@GetMapping("/hash")
public String CheckSum() throws NoSuchAlgorithmException {
	String msg = "Hello Dakota Osborne.";
	
	MessageDigest mDig = MessageDigest.getInstance("SHA3-512");//Create message digest object with SHA3-512 hash algorithm 
	byte [] msgByte = mDig.digest(msg.getBytes());//Digest message 
	String hexHash = HexFormat.of().formatHex(msgByte);//Convert the hash into hex value
	return("<p> <br>Message: " + msg +" <br> Hash used: SHA3-512 <br> Hash value: " +  hexHash + "</p> ");
}
}
