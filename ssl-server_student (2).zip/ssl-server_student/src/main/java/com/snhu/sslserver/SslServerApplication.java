package com.snhu.sslserver;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.net.SocketFactory;
import javax.net.ssl.SSLSocketFactory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import javax.net.ssl*;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) throws UnknownHostException, IOException {
		SpringApplication.run(SslServerApplication.class, args);
		SocketFactory sf = SSLSocketFactory.getDefault();
		Socket socket = sf.createSocket("localhost", 8443);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";